﻿namespace Lab3
{
    partial class Bai4_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnBuy = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.labelPhim = new System.Windows.Forms.Label();
            this.panelDPP1 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labelManHinh = new System.Windows.Forms.Label();
            this.labelInfo = new System.Windows.Forms.Label();
            this.panelDPP1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(113, 27);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(366, 22);
            this.txtName.TabIndex = 7;
            // 
            // labelName
            // 
            this.labelName.Location = new System.Drawing.Point(33, 30);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(85, 25);
            this.labelName.TabIndex = 6;
            this.labelName.Text = "Name";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(608, 296);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(144, 48);
            this.btnDisconnect.TabIndex = 10;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnBuy
            // 
            this.btnBuy.Location = new System.Drawing.Point(608, 181);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(144, 48);
            this.btnBuy.TabIndex = 9;
            this.btnBuy.Text = "Buy";
            this.btnBuy.UseVisualStyleBackColor = true;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(608, 64);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(144, 48);
            this.btnConnect.TabIndex = 8;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Mai",
            "Gặp lại chị bầu"});
            this.comboBox1.Location = new System.Drawing.Point(113, 80);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(366, 24);
            this.comboBox1.TabIndex = 11;
            // 
            // labelPhim
            // 
            this.labelPhim.Location = new System.Drawing.Point(33, 80);
            this.labelPhim.Name = "labelPhim";
            this.labelPhim.Size = new System.Drawing.Size(74, 25);
            this.labelPhim.TabIndex = 12;
            this.labelPhim.Text = "Movie";
            // 
            // panelDPP1
            // 
            this.panelDPP1.Controls.Add(this.button15);
            this.panelDPP1.Controls.Add(this.button14);
            this.panelDPP1.Controls.Add(this.button13);
            this.panelDPP1.Controls.Add(this.button12);
            this.panelDPP1.Controls.Add(this.button11);
            this.panelDPP1.Controls.Add(this.button10);
            this.panelDPP1.Controls.Add(this.button9);
            this.panelDPP1.Controls.Add(this.button8);
            this.panelDPP1.Controls.Add(this.button7);
            this.panelDPP1.Controls.Add(this.button6);
            this.panelDPP1.Controls.Add(this.button5);
            this.panelDPP1.Controls.Add(this.button4);
            this.panelDPP1.Controls.Add(this.button3);
            this.panelDPP1.Controls.Add(this.button2);
            this.panelDPP1.Controls.Add(this.button1);
            this.panelDPP1.Controls.Add(this.labelManHinh);
            this.panelDPP1.Location = new System.Drawing.Point(101, 134);
            this.panelDPP1.Name = "panelDPP1";
            this.panelDPP1.Size = new System.Drawing.Size(400, 228);
            this.panelDPP1.TabIndex = 13;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(337, 183);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(39, 23);
            this.button15.TabIndex = 15;
            this.button15.Text = "C5";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(256, 183);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(42, 23);
            this.button14.TabIndex = 14;
            this.button14.Text = "C4";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(179, 183);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(44, 23);
            this.button13.TabIndex = 13;
            this.button13.Text = "C3";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(96, 183);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(45, 23);
            this.button12.TabIndex = 12;
            this.button12.Text = "C2";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(22, 183);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(46, 23);
            this.button11.TabIndex = 11;
            this.button11.Text = "C1";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(337, 123);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(39, 23);
            this.button10.TabIndex = 10;
            this.button10.Text = "B5";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(256, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(42, 23);
            this.button9.TabIndex = 9;
            this.button9.Text = "B4";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(179, 123);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(44, 23);
            this.button8.TabIndex = 8;
            this.button8.Text = "B3";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(96, 123);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(45, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "B2";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(22, 123);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(46, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "B1";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(337, 71);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(39, 23);
            this.button5.TabIndex = 5;
            this.button5.Text = "A5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(256, 71);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(42, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "A4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(179, 71);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(44, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "A3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(96, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "A2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(22, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(46, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "A1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button_Click);
            // 
            // labelManHinh
            // 
            this.labelManHinh.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelManHinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelManHinh.Location = new System.Drawing.Point(0, 0);
            this.labelManHinh.Name = "labelManHinh";
            this.labelManHinh.Size = new System.Drawing.Size(397, 52);
            this.labelManHinh.TabIndex = 0;
            this.labelManHinh.Text = "            Màn Hình";
            // 
            // labelInfo
            // 
            this.labelInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelInfo.Location = new System.Drawing.Point(101, 394);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(400, 23);
            this.labelInfo.TabIndex = 14;
            // 
            // Bai4_Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.panelDPP1);
            this.Controls.Add(this.labelPhim);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnBuy);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelName);
            this.Name = "Bai4_Client";
            this.Text = "Bai4_Client";
            this.Load += new System.EventHandler(this.Bai4_Client_Load);
            this.panelDPP1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label labelPhim;
        private System.Windows.Forms.Panel panelDPP1;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelManHinh;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Button button13;
    }
}